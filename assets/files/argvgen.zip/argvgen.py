import os
import shutil
successful_argvs = 0

print("ARGV Helper by jerbear64 and Jhynjhiruu")
if os.path.exists("dsiware"): shutil.rmtree("dsiware")
os.mkdir("dsiware")

for app in os.listdir(os.getcwd()):
    try:       
        for title in os.listdir(app + "/content/"):
            if title.endswith(".app"):
                print("Found app at /{0}/content/{1}\nGenerating argv...".format(app, title))
                with open("dsiware/{}.argv".format(app), "w") as argv: argv.write("sd:/title/00030004/" + app + "/content/" + title)
                successful_argvs = successful_argvs + 1
    except:pass 
print("Generated argvs for {} title(s) successfully".format(successful_argvs))
